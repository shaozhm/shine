jQuery.sap.declare("shine.democontent.epm.usercrud.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("shine.democontent.epm.usercrud.Component", {
	metadata: {
		"manifest": "json"
	}
});
